package com.example.assistant

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.*
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.WindowManager

class AssistantService : Service() {
    companion object {
        const val ACTION_START = "start"
        const val ACTION_LISTEN = "listen"
        const val ACTION_TEXT = "text"
        /** Отступ капсулы от верха экрана (dp). Подгони под свою камеру. */
        const val TOP_OFFSET_DP = 4
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val hide = Runnable { hideOverlay() }
    private var overlay: IslandView? = null
    private var recognizer: SpeechRecognizer? = null
    private val dp get() = resources.displayMetrics.density

    private val aliases = mapOf(
        "ватсап" to "whatsapp", "вотсап" to "whatsapp", "ютуб" to "youtube",
        "телеграм" to "telegram", "инстаграм" to "instagram", "хром" to "chrome",
        "карты" to "maps", "почта" to "gmail", "гугл" to "google"
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("assistant", "Помощник", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getService(
            this, 0, Intent(this, AssistantService::class.java).setAction(ACTION_LISTEN),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "assistant")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Помощник работает")
            .setContentText("Нажми «Слушать» и говори")
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_btn_speak_now), "Слушать", pi).build())
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_LISTEN -> startListening()
            ACTION_TEXT -> {
                val t = intent.getStringExtra("text").orEmpty()
                showOverlay(t); handler.postDelayed({ handle(t) }, 500)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        recognizer?.destroy(); hideOverlay(); super.onDestroy()
    }

    // ---------- Голос ----------
    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            say("Нет доступа к микрофону"); return
        }
        showOverlay("Слушаю…")
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) { overlay?.level = ((rms + 2) / 12f).coerceIn(0f, 1f) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { overlay?.level = 0f }
                override fun onError(e: Int) { say("Не расслышал") }
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t == null) say("Не расслышал") else { overlay?.text = t; handle(t) }
                }
                override fun onPartialResults(p: Bundle?) {
                    p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { overlay?.text = it }
                }
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true))
        }
    }

    // ---------- Команды ----------
    private fun handle(raw: String) {
        val t = raw.lowercase().replace("пожалуйста", "").trim().trimEnd('.', '!', '?')
        val call = Regex("^(позвони|набери|вызови|позвонить)\\s+(.+)$").find(t)
        val open = Regex("^(открой|запусти|включи|открыть)\\s+(.+)$").find(t)
        when {
            call != null -> callContact(call.groupValues[2].trim())
            open != null -> openApp(open.groupValues[2].trim())
            else -> say("Не понял: $raw")
        }
    }

    private fun callContact(name: String) {
        val digits = name.replace(" ", "")
        val number = if (digits.matches(Regex("\\+?\\d{5,}"))) digits else findNumber(name)
        if (number == null) { say("Не нашёл контакт «$name»"); return }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            say("Нет разрешения на звонки"); return
        }
        say("Звоню: $name")
        launchLater(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))))
    }

    private fun findNumber(name: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        // «маме» -> «мам»: пробуем усечённые формы, чтобы пережить падежи
        val variants = listOf(name, name.dropLast(1), name.dropLast(2)).filter { it.length >= 2 }.distinct()
        contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null)?.use { c ->
            val all = mutableListOf<Pair<String, String>>()
            while (c.moveToNext()) all += (c.getString(0) ?: "").lowercase() to (c.getString(1) ?: "")
            for (v in variants) all.firstOrNull { it.first.contains(v) }?.let { return it.second }
        }
        return null
    }

    private fun openApp(name: String) {
        val special = when {
            name.startsWith("телефон") || name.startsWith("звонилк") -> Intent(Intent.ACTION_DIAL)
            name.startsWith("настройк") -> Intent(Settings.ACTION_SETTINGS)
            name.startsWith("камер") -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            else -> null
        }
        if (special != null) { say("Открываю $name"); launchLater(special); return }

        val q = aliases[name] ?: aliases[name.dropLast(1)] ?: if (name.length > 4) name.dropLast(1) else name
        val pm = packageManager
        val app = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
        val launch = app?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (launch == null) { say("Не нашёл приложение «$name»"); return }
        say("Открываю ${app.loadLabel(pm)}")
        launchLater(launch)
    }

    /** Даём анимации показаться, потом запускаем. Из фона можно благодаря разрешению «поверх экрана». */
    private fun launchLater(i: Intent) {
        handler.postDelayed({ startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, 700)
    }

    // ---------- Оверлей ----------
    private fun say(msg: String) {
        showOverlay(msg)
        handler.postDelayed(hide, 2200)
    }

    private fun showOverlay(msg: String) {
        handler.removeCallbacks(hide)
        if (!Settings.canDrawOverlays(this)) return
        if (overlay == null) {
            val v = IslandView(this)
            val width = minOf(resources.displayMetrics.widthPixels * 0.92f, 360 * dp).toInt()
            val lp = WindowManager.LayoutParams(
                width, (60 * dp).toInt(),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = (TOP_OFFSET_DP * dp).toInt()
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
            wm.addView(v, lp)
            overlay = v
            v.post { v.expand() }
        }
        overlay?.text = msg
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        overlay = null
        v.collapse { runCatching { wm.removeView(v) } }
    }
}
