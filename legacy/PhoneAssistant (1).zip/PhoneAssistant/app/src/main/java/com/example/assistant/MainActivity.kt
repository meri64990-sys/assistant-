package com.example.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * dp).toInt(), (64 * dp).toInt(), (20 * dp).toInt(), (20 * dp).toInt())
        }
        fun btn(t: String, f: () -> Unit) {
            root.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        }
        fun send(action: String, text: String? = null) {
            val i = Intent(this, AssistantService::class.java).setAction(action)
            if (text != null) i.putExtra("text", text)
            startForegroundService(i)
        }

        btn("1. Разрешить поверх экрана") {
            if (!Settings.canDrawOverlays(this))
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Микрофон, контакты, звонки, уведомления") {
            requestPermissions(arrayOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("3. Запустить помощника") { send(AssistantService.ACTION_START) }
        btn("🎤 Слушать") { send(AssistantService.ACTION_LISTEN) }

        val input = EditText(this).apply { hint = "Команда текстом: открой ютуб / позвони маме" }
        root.addView(input)
        btn("Отправить") {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) { send(AssistantService.ACTION_TEXT, t); input.text.clear() }
        }
        setContentView(root)
    }
}
